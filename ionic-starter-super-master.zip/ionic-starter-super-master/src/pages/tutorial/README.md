# Tutorial

The Tutorial page renders a Slides component that lets you swipe through different sections or skip it alltogether.
