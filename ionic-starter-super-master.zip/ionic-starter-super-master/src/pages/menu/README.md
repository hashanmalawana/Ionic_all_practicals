# Menu

The Menu page renders a side menu UI.
